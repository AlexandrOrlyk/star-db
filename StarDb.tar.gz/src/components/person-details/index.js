import React from "react";
import { SwapiServer } from "../../client/SwapiServer";
import "./person-details.css";

export const PersonDetails = () => {
  const swapi = new SwapiServer();

  const res = swapi.getPerson(3).then((res) => {
    return res;
  });

  return (
    <div className="person_wrapper">     
      <div className="info_container">
        <div className='person_item'>132123132</div>  
        <div className='person_item'>132123132</div>       
      </div>
    </div>
  );
};
