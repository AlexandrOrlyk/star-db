import React, { useState, useEffect } from "react";
import { SwapiServer } from "../../client/SwapiServer";
import "./random-planet.css";

export const RandomPlanet = () => {
  const [planetState, setPlanetState] = useState([]);

  useEffect(() => {
    const swapi = new SwapiServer();
    const id = Math.floor(Math.random() * 25 + 2);
    
    
    swapi.getPlanet(id).then((res) => {
      setPlanetState({ ...res, id: id });
    });
  }, []);
 
  
  console.log("planetState", planetState);
  return (
    <div className="planet_wrapper">
      {/* {planetState.map((item) => ( */}
      <>
        <img
          className="planet_img"
          src={`https://starwars-visualguide.com/assets/img/planets/${planetState.id}.jpg`}
          alt=""
        />
        <div className="info_container">
          <div className="planet_name">{planetState.name}</div>
          <div>
            <div className="planet_item">
              <span className="item_name">Population</span>
              <span>{planetState.population}</span>
            </div>
            <div className="planet_item">
              <span className="item_name">RotationPeriod</span>
              <span>{planetState.rotation_period}</span>
            </div>
            <div className="planet_item">
              <span className="item_name">Diameter</span>
              <span>{planetState.diameter}</span>
            </div>
          </div>
        </div>
      </>
      {/* ))} */}
    </div>
  );
};
