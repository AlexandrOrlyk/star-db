import './spinner.css'

export const Spinner = () => {
  return (
    <div className="loadingio-spinner-eclipse-l29ut355cak">
      <div className="ldio-9b45ub0tt39">
        <div></div>
      </div>
    </div>
  );
};
